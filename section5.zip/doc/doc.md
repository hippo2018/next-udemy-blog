https://note.com/aoki_monpro/n/nd695fc29792c

volta install node

volta install npm

npx create-next-app@^15

npm run lint

拡張機能
ES7 React/Redux/GraphQL/React-Native snippets
Auto Import
Dark-Dracula Theme
Git Graph
GitHub Codespaces
Highlight Matching Tag
indent-rainbow
Material Icon Theme
Prettify TypeScript: Better Type Previews
Tailwind CSS IntelliSense

rfc

クロムに
JSONVue

https://nextjs.org/docs/app/api-reference/functions/generate-metadata#metadata-fields

git archive --format=zip --output=zibunfin.zip HEAD

npm install zod@^3

npm install prisma@^6
npm install @prisma/client@^6
npx prisma init

// マイグレーション(テーブル作成)
npx prisma migrate dev --name init
// シード実行(ダミーデータ)
npx prisma db seed
// DBの内容を確認
npx prisma studio
// DBリセット
npx prisma migrate reset

github
git init
git add README.md
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/hippo2018/next-udemy-blog.git
git push -u origin main

git add .
git commit -m "prisma setting"

npx shadcn@latest init
base color > Neutral
Use --force

npx shadcn@latest init
base color > Neutral
Use --force

npx shadcn@latest add navigation-menu button input label alert dropdown-menu alert-dialog
npx shadcn@latest add card

npm install date-fns@^4

npx shadcn@latest add card