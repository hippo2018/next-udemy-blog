export default function NotFound() {
  return (
    <div>
      お探しの記事は存在しないか、削除された可能性があります。
    </div>
  )
}
