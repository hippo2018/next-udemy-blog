UdemyのNext.js フルスタック講座で扱ったサンプルコードになります。


## ダウンロード方法

git clone git@github.com:aokitashipro/next-udemy-basic.git

cd next-udemy-blog

.envファイルを作成

npm install // 必要なライブラリをインストール

npm run dev // 開発サーバー起動

npm run build // ビルド