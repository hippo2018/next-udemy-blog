export default function ProfilePage() {
  return (
    <div>
      プロフィール
    </div>
  )
}
