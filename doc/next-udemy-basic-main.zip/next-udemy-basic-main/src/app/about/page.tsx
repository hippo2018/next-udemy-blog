export default function AboutPage() {
  return (
    <div>About</div>
  )
}
