
export default function NotFound() {
  return (
    <div>
      そのページは存在しません
    </div>
  )
}
