
export default function RegisterPage() {
  return (
    <div>
      ユーザー登録
    </div>
  )
}
