export default function LoginPage() {
  return (
    <div>
      ログイン
    </div>
  )
}
