export default function CompletePage() {
  return (
    <div>
      送信完了しました
    </div>
  )
}
