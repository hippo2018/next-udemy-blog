'use client'
export default function error() {
  return (
    <div>
      エラーが発生しました
    </div>
  )
}
