// import { getOwnPosts } from "@/lib/ownPost"
// import { auth } from '@/auth'
// import PostDropdownMenu from "@/components/post/PostDropdownMenu"
// import { Button } from '@/components/ui/button'
// import Link from 'next/link'

export default async function DashBoardPage() {
  // const session = await auth()
  // const userId = session?.user?.id
  // if(!session?.user?.email || !userId){
  //   throw new Error('不正なリクエストです')
  // }

  // const posts = await getOwnPosts(userId)
  return (
    <div>
      dashuboard
    </div>
  );
}